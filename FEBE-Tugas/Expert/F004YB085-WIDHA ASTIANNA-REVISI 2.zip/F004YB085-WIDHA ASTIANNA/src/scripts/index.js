import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';
import '../styles/responsive.css';
import '../component/app-bar.js';

console.log('Hello Coders! :)');
